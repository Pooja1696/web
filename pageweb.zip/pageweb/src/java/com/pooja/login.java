/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pooja;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author Pooja
 */
@WebServlet("/log")
public class login extends HttpServlet{
    
      public void service(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
          PrintWriter out=response.getWriter();
          String name=(String)request.getParameter("username");
          String pass=(String)request.getParameter("password");
          String nnn=("Pooja Mishra");
//          out.println("username "+name);
//          out.print("password "+pass);
       
         if(name.equals("admin") && pass.equals("admin123"))
         {
               RequestDispatcher rd=request.getRequestDispatcher("log.jsp");
               request.setAttribute("username", name);
               request.setAttribute("password",pass);
               request.setAttribute("Pooja",nnn);
               rd.forward(request, response);
         }
         else{
             response.sendRedirect("index.jsp");
         }



      
          
          
          
      }
}
